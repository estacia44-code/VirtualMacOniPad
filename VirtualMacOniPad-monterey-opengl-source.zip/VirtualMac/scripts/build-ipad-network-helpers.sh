#!/bin/bash

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# shellcheck source=lib/common.sh
source "$SCRIPT_DIR/lib/common.sh"

SOURCE_ROOT="$VZ_BUILD_ROOT/inputs/macos/22D68__MacOS"
SOURCE_BOOTPD="$SOURCE_ROOT/usr/libexec/bootpd"
SOURCE_IPADOS14_BOOTPD="$VZ_BUILD_ROOT/inputs/ipados14/18E199__iPad13,4_5_6_7/usr/libexec/bootpd"
SOURCE_RTADVD="$SOURCE_ROOT/usr/sbin/rtadvd"
SOURCE_BOOTPD_PLIST="$SOURCE_ROOT/System/Library/LaunchDaemons/bootps.plist"
ENTS="$VZ_REPO_ROOT/vz/patches/network-helper.ents.xml"
COMPAT_PATCH="$VZ_REPO_ROOT/vz/patches/patch_network_helper.py"
IPADOS14_PATCH="$VZ_REPO_ROOT/vz/patches/patch_ipados14_bootpd.py"
ADD_DYLIB="$VZ_REPO_ROOT/vz/patches/add_macho_dylib.py"
OUT="$VZ_BUILD_ROOT/ipad-network-helpers"
BOOTPD="$OUT/bootpd"
BOOTPD_IPADOS14="$OUT/bootpd.ipados14"
RTADVD="$OUT/rtadvd"
OD_COMPAT="$OUT/OpenDirectoryCompat.dylib"
IOKIT14_COMPAT="$OUT/IOKit14Compat.dylib"
BOOTPD_PLIST="$OUT/com.apple.bootpd.plist"

need_command codesign
need_command install_name_tool
need_command ldid
need_command lipo
need_command plutil
need_file "$SOURCE_BOOTPD"
need_file "$SOURCE_IPADOS14_BOOTPD"
need_file "$SOURCE_RTADVD"
need_file "$SOURCE_BOOTPD_PLIST"
need_file "$ENTS"
need_file "$COMPAT_PATCH"
need_file "$IPADOS14_PATCH"
need_file "$ADD_DYLIB"

rm -rf "$OUT"
mkdir -p "$OUT"

xcrun --sdk iphoneos clang \
    -arch arm64e -miphoneos-version-min="$VZ_IPADOS_MIN_VERSION" \
    -isysroot "$(xcrun --sdk iphoneos --show-sdk-path)" \
    -dynamiclib -framework CoreFoundation \
    -install_name @loader_path/../lib/OpenDirectoryCompat.dylib \
    "$VZ_REPO_ROOT/vz/host/open_directory_compat.c" \
    -o "$OD_COMPAT"
codesign --force --sign - "$OD_COMPAT"
xcrun --sdk iphoneos clang \
    -arch arm64e -miphoneos-version-min=14.5 \
    -isysroot "$(xcrun --sdk iphoneos --show-sdk-path)" \
    -dynamiclib -framework CoreFoundation -framework IOKit \
    -Wl,-reexport_framework,IOKit \
    -install_name @loader_path/../lib/IOKit14Compat.dylib \
    "$VZ_REPO_ROOT/vz/host/iokit14_compat.c" \
    -o "$IOKIT14_COMPAT"
codesign --force --sign - "$IOKIT14_COMPAT"

for source in "$SOURCE_BOOTPD" "$SOURCE_RTADVD"; do
    name="$(basename "$source")"
    lipo -thin arm64e "$source" -output "$OUT/$name.macos"
done

install_name_tool \
    -change /System/Library/Frameworks/CoreFoundation.framework/Versions/A/CoreFoundation \
    /System/Library/Frameworks/CoreFoundation.framework/CoreFoundation \
    -change /System/Library/Frameworks/SystemConfiguration.framework/Versions/A/SystemConfiguration \
    /System/Library/Frameworks/SystemConfiguration.framework/SystemConfiguration \
    -change /System/Library/Frameworks/OpenDirectory.framework/Versions/A/OpenDirectory \
    @loader_path/../lib/OpenDirectoryCompat.dylib \
    -change /System/Library/Frameworks/IOKit.framework/Versions/A/IOKit \
    /System/Library/Frameworks/IOKit.framework/IOKit \
    "$OUT/bootpd.macos"

for name in bootpd rtadvd; do
    "$VZ_BUILD_ROOT/toolchain/venv/bin/python3" \
        "$VZ_REPO_ROOT/vz/stamp_ios.py" "$OUT/$name.macos" "$OUT/$name" \
        "$VZ_IPADOS_MIN_VERSION"
    codesign --force --sign - --entitlements "$ENTS" \
        --generate-entitlement-der "$OUT/$name"
    codesign --verify --strict "$OUT/$name"
    rm -f "$OUT/$name.macos"
done

"$VZ_BUILD_ROOT/toolchain/venv/bin/python3" "$COMPAT_PATCH" "$BOOTPD"
"$VZ_BUILD_ROOT/toolchain/venv/bin/python3" "$ADD_DYLIB" "$BOOTPD" \
    @loader_path/../lib/NetworkMemoryPolicy.dylib
codesign --force --sign - --entitlements "$ENTS" \
    --generate-entitlement-der "$BOOTPD"
codesign --verify --strict "$BOOTPD"

# Preserve the matching iPadOS 14 implementation and modify only its writable
# configuration pathname. Never install this file over /usr/libexec/bootpd.
cp "$SOURCE_IPADOS14_BOOTPD" "$BOOTPD_IPADOS14"
"$VZ_BUILD_ROOT/toolchain/venv/bin/python3" "$IPADOS14_PATCH" \
    "$BOOTPD_IPADOS14"
"$VZ_BUILD_ROOT/toolchain/venv/bin/python3" "$ADD_DYLIB" \
    "$BOOTPD_IPADOS14" @loader_path/../lib/NetworkMemoryPolicy.dylib
codesign --force --sign - --entitlements "$ENTS" \
    --generate-entitlement-der "$BOOTPD_IPADOS14"
codesign --verify --strict "$BOOTPD_IPADOS14"
codesign --verify --strict "$OD_COMPAT"
codesign --verify --strict "$IOKIT14_COMPAT"
for executable in "$BOOTPD" "$BOOTPD_IPADOS14"; do
    otool -L "$executable" | grep -Fq \
        @loader_path/../lib/NetworkMemoryPolicy.dylib ||
        die "network memory policy is not loaded by $executable"
done
python3 "$VZ_REPO_ROOT/scripts/audit-entitlements.py" \
    "$ENTS" "$BOOTPD" \
    "$ENTS" "$BOOTPD_IPADOS14" \
    "$ENTS" "$RTADVD" \
    - "$OD_COMPAT" \
    - "$IOKIT14_COMPAT"

cp "$SOURCE_BOOTPD_PLIST" "$BOOTPD_PLIST"
plutil -replace Label -string vzi.apple.bootpd "$BOOTPD_PLIST"
plutil -replace ProgramArguments -json \
    '["/var/jb/usr/libexec/bootpd"]' "$BOOTPD_PLIST"
plutil -insert Program -string /var/jb/usr/libexec/bootpd "$BOOTPD_PLIST"
plutil -replace Disabled -bool NO "$BOOTPD_PLIST"
plutil -insert UserName -string root "$BOOTPD_PLIST"
plutil -insert POSIXSpawnType -string Interactive "$BOOTPD_PLIST"
plutil -insert ProcessType -string Interactive "$BOOTPD_PLIST"
plutil -insert ExecuteAllowed -bool YES "$BOOTPD_PLIST"
plutil -insert StandardOutPath -string /tmp/bootpd.out "$BOOTPD_PLIST"
plutil -insert StandardErrorPath -string /tmp/bootpd.err "$BOOTPD_PLIST"
plutil -lint "$BOOTPD_PLIST"

echo "iPad NetworkSharing helpers built: $OUT"
